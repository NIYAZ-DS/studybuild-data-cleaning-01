# Project 01 — E-commerce Customer Data Cleaning

## Objective
Inspect, audit, clean, validate, and prepare the raw e-commerce customer dataset for reliable downstream analysis.

## Workflow
1. Data understanding
2. Data quality audit
3. Missing, duplicate, type, range and business-rule checks
4. Explicit cleaning decisions
5. Working-layer quality controls
6. Post-cleaning validation
7. Clean dataset export
8. Descriptive visualization

## Key design decision
Temporary audit/quality columns are not added to the final business dataset. They belong in the working layer or audit files.

## Cleaning rules
- Exact duplicate rows: remove.
- Age outside 18–100: invalid → NaN → median imputation.
- Missing/inconsistent total_spending: recalculate as purchase_count × avg_order_value.
- returned_items > purchase_count: cap at purchase_count.
- signup_date: convert to datetime.
- Text fields: strip surrounding whitespace.
- Statistical outliers: flag/review; do not automatically delete.

## Deliverables
- data/raw_dataset.xlsx
- data/cleaned_dataset.xlsx
- notebook/data_cleaning.ipynb
- report/quality_audit.xlsx
- report/cleaning_issue_log.xlsx
- report/validation_before_after.xlsx
- report/cleaning_report.pdf

