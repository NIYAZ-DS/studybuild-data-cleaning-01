import pandas as pd
import matplotlib.pyplot as plt

# ==========================
# Read original Excel file
df = pd.read_excel("data/First Dataset.xlsx")

# ==========================
# Remove rows with missing values
# ==========================
clean_data = df.dropna()

# ==========================
# Keep only valid ages
# (17 <= age <= 90)
# ==========================
clean_data = clean_data[
    (clean_data["age"] >= 17) &
    (clean_data["age"] <= 90)
]

# ==========================
# Save cleaned dataset
# ==========================
clean_data.to_excel(
    "Clean_Data.xlsx",
    index=False
)

print("Clean dataset saved successfully.")
print(f"Rows after cleaning: {clean_data.shape[0]}")
#___________________________________

city_returns = (
    clean_data
    .groupby("city")["returned_items"]
    .sum()
    .sort_values(ascending=False)
)

print(city_returns)

city_returns.plot(
    kind="bar",
    figsize=(8,5)
)

plt.title("Returned Items by City")
plt.xlabel("City")
plt.ylabel("Returned Items")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#--------------------------------------------
discount_city = (
    clean_data[clean_data["discount_used"] == "Yes"]
    .groupby("city")
    .size()
    .sort_values(ascending=False)
)

print(discount_city)

discount_city.plot(
    kind="bar",
    figsize=(8,5)
)

plt.title("Discount Usage by City")
plt.xlabel("City")
plt.ylabel("Number of Customers")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#--------------------------------------------


#--------------------------------------------


